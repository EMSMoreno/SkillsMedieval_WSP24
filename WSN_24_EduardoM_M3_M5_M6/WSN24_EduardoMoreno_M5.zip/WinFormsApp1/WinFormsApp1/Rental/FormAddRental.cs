﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WSN24_EduardoMoreno_M3.Rental
{
    public partial class FormAddRental : Form
    {
        string cs = ConfigurationManager.ConnectionStrings["WSP_EduardoMoreno"].ConnectionString;
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adapter;
        DataTable dt;

        public FormAddRental()
        {
            InitializeComponent();
        }

        // Method to load rentals data from the database into the DataGridView
        private void FormAddRental_Load(object sender, EventArgs e)
        {
            LoadRentals();
            // Add status options to ComboBox
            cmbStatus.Items.Add("In Progress");
            cmbStatus.Items.Add("Completed");
            cmbStatus.Items.Add("Not Returned");

            // Set default selected item for the ComboBox
            cmbStatus.SelectedIndex = 0; // Default to "In Progress"
        }

        // Method to clear the form fields
        private void CleanAddRentalForm()
        {
            dtpRentalDate.Value = DateTime.Now;  // Reset rental date to current date
            dtpReturnDate.Value = DateTime.Now;  // Reset return date to current date
            cmbStatus.SelectedIndex = 0;         // Reset status to "In Progress"
        }

        private void LoadRentals()
        {
            try
            {
                using (con = new SqlConnection(cs))
                {
                    con.Open();
                    string query = @"
                        SELECT 
                            rental_id, 
                            rental_date, 
                            return_date, 
                            status
                        FROM rentals";
                    SqlCommand cmd = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dataGridSearchRentals.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while loading rentals: " + ex.Message);
            }
        }

        private void btnAddRental_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate input fields
                if (dtpRentalDate.Value == DateTime.MinValue || string.IsNullOrEmpty(cmbStatus.SelectedItem.ToString()))
                {
                    MessageBox.Show("Please fill in all the required fields.");
                    return;
                }

                using (con = new SqlConnection(cs))
                {
                    con.Open();

                    // Insert the rental details into the database
                    string query = @"
                    INSERT INTO rentals
                    (rental_date, return_date, status)
                    VALUES
                    (@RentalDate, @ReturnDate, @Status)";

                    cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@RentalDate", dtpRentalDate.Value);
                    cmd.Parameters.AddWithValue("@ReturnDate", dtpReturnDate.Value);
                    cmd.Parameters.AddWithValue("@Status", cmbStatus.SelectedItem.ToString());

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Rental added successfully!");

                    CleanAddRentalForm(); // Clean the form after adding rental
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while adding rental: " + ex.Message);
            }
        }

        private void btnCleanForm_Click(object sender, EventArgs e)
        {
            CleanAddRentalForm();
        }

        private void SearchRentals(string criterio)
        {
            try
            {
                using (con = new SqlConnection(cs))
                {
                    con.Open();
                    string query = @"
            SELECT 
                rental_id, 
                rental_date, 
                return_date, 
                status
            FROM rentals
            WHERE 
                CAST(rental_date AS VARCHAR) LIKE @Criterio 
                OR CAST(return_date AS VARCHAR) LIKE @Criterio 
                OR status LIKE @Criterio";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@Criterio", "%" + criterio + "%");

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dataGridSearchRentals.DataSource = dt;

                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("No rentals found with the given search criteria.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while searching for rentals: " + ex.Message);
            }
        }

        private void btnSearchOrganizer_Click(object sender, EventArgs e)
        {
            string criterio = txtSearchRental.Text.Trim();

            if (string.IsNullOrEmpty(criterio))
            {
                MessageBox.Show("Please enter a search criterion.");
                return;
            }

            SearchRentals(criterio);
        }

        private void CleanSearchRentalForm()
        {
            txtSearchRental.Clear();
            dataGridSearchRentals.DataSource = null;
        }

        private void btnCleanFormSearch_Click(object sender, EventArgs e)
        {
            CleanSearchRentalForm();
        }
    }
}

