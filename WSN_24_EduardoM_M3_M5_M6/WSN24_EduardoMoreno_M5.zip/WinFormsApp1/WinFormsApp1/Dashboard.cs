﻿using Microsoft.VisualBasic.Logging;
using Microsoft.VisualBasic;
using WSN24_EduardoMoreno_M3;
using WSN24_EduardoMoreno_M3.Cliente;
using WSN24_EduardoMoreno_M3.Costume;
using WSN24_EduardoMoreno_M3.Events;
using WSN24_EduardoMoreno_M3.Organizers;
using WSN24_EduardoMoreno_M3.Rental;
using WSN24_EduardoMoreno_M3.Users;
using WSN24_EduardoMoreno_M3.Warehouse;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WinFormsApp1
{
    public partial class Dashboard : Form
    {
        private int loggedUserId;

        private int userId;

        public Dashboard(int userId)
        {
            InitializeComponent();
            loggedUserId = userId;
            this.userId = userId;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (FormSeeClient formVerCliente = new FormSeeClient())
            { formVerCliente.ShowDialog(); }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (FormSeeCostume formSeeCostume = new FormSeeCostume())
            { formSeeCostume.ShowDialog(); }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (FormSeeEvent formSeeEvent = new FormSeeEvent())
            { formSeeEvent.ShowDialog(); }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            using (FormSeeOrganizer formSeeOrganizer = new FormSeeOrganizer())
            { formSeeOrganizer.ShowDialog(); }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            using (FormSeeRental formSeeRental = new FormSeeRental())
            { formSeeRental.ShowDialog(); }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            using (FormSeeWarehouse formSeeWarehouse = new FormSeeWarehouse())
            { formSeeWarehouse.ShowDialog(); }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            using (FormSeeUser formSeeUser = new FormSeeUser(loggedUserId))
            {
                formSeeUser.ShowDialog();
            }
        }

        // Users e admin

        private void button8_Click(object sender, EventArgs e)
        {
            using (FormSeeClient formVerform = new FormSeeClient())
            { formVerform.ShowDialog(); }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            using (FormSeeClient formVerform = new FormSeeClient())
            { formVerform.ShowDialog(); }
        }

        //Logs Button

        private void btnLogs_Click(object sender, EventArgs e)
        {
            using (FormLogs formLogs = new FormLogs())
            { formLogs.ShowDialog(); }
        }

        # region Logout Button
        private void btnLogout_Click(object sender, EventArgs e)
        {
            // Clear session variables(e.g.userId, any information associated with the login)
            this.userId = 0;

            // Close the Dashboard form
            this.Close();

            // Opens FormLogin
            FormLogin formLogin = new FormLogin();
            formLogin.Show();
        }

        #endregion
    }
}
