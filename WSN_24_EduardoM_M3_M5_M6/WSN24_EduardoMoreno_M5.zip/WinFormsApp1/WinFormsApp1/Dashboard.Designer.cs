﻿namespace WinFormsApp1
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            groupBox1 = new GroupBox();
            btnClientsMenu = new Button();
            groupBox2 = new GroupBox();
            button2 = new Button();
            groupBox3 = new GroupBox();
            button3 = new Button();
            groupBox4 = new GroupBox();
            button4 = new Button();
            groupBox5 = new GroupBox();
            button5 = new Button();
            groupBox6 = new GroupBox();
            button6 = new Button();
            groupBox7 = new GroupBox();
            button7 = new Button();
            groupBox8 = new GroupBox();
            button8 = new Button();
            groupBox9 = new GroupBox();
            button9 = new Button();
            panel1 = new Panel();
            label2 = new Label();
            btnLogs = new Button();
            btnLogout = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            groupBox5.SuspendLayout();
            groupBox6.SuspendLayout();
            groupBox7.SuspendLayout();
            groupBox8.SuspendLayout();
            groupBox9.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(399, 38);
            label1.Name = "label1";
            label1.Size = new Size(479, 50);
            label1.TabIndex = 0;
            label1.Text = "Welcome to SkillsMedieval4All.\r\nPlease select one of the options below and have fun.";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnClientsMenu);
            groupBox1.Location = new Point(61, 135);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(349, 155);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            // 
            // btnClientsMenu
            // 
            btnClientsMenu.FlatAppearance.BorderColor = Color.Red;
            btnClientsMenu.FlatStyle = FlatStyle.Flat;
            btnClientsMenu.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnClientsMenu.Location = new Point(32, 48);
            btnClientsMenu.Name = "btnClientsMenu";
            btnClientsMenu.Size = new Size(269, 81);
            btnClientsMenu.TabIndex = 2;
            btnClientsMenu.Text = "Clients";
            btnClientsMenu.UseVisualStyleBackColor = true;
            btnClientsMenu.Click += button1_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(button2);
            groupBox2.Location = new Point(464, 135);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(349, 155);
            groupBox2.TabIndex = 2;
            groupBox2.TabStop = false;
            groupBox2.Text = "groupBox2";
            // 
            // button2
            // 
            button2.FlatAppearance.BorderColor = Color.FromArgb(0, 192, 192);
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.Location = new Point(32, 48);
            button2.Name = "button2";
            button2.Size = new Size(269, 81);
            button2.TabIndex = 2;
            button2.Text = "Costumes";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(button3);
            groupBox3.Location = new Point(864, 135);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(349, 155);
            groupBox3.TabIndex = 3;
            groupBox3.TabStop = false;
            groupBox3.Text = "groupBox3";
            // 
            // button3
            // 
            button3.FlatAppearance.BorderColor = Color.FromArgb(128, 128, 255);
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button3.Location = new Point(32, 48);
            button3.Name = "button3";
            button3.Size = new Size(269, 81);
            button3.TabIndex = 2;
            button3.Text = "Events";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(button4);
            groupBox4.Location = new Point(61, 342);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(349, 155);
            groupBox4.TabIndex = 3;
            groupBox4.TabStop = false;
            groupBox4.Text = "groupBox4";
            // 
            // button4
            // 
            button4.FlatAppearance.BorderColor = Color.Yellow;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button4.Location = new Point(32, 48);
            button4.Name = "button4";
            button4.Size = new Size(269, 81);
            button4.TabIndex = 2;
            button4.Text = "Organizers";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(button5);
            groupBox5.Location = new Point(464, 342);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(349, 155);
            groupBox5.TabIndex = 3;
            groupBox5.TabStop = false;
            groupBox5.Text = "groupBox5";
            // 
            // button5
            // 
            button5.FlatAppearance.BorderColor = Color.LawnGreen;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button5.Location = new Point(32, 48);
            button5.Name = "button5";
            button5.Size = new Size(269, 81);
            button5.TabIndex = 2;
            button5.Text = "Rentals";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // groupBox6
            // 
            groupBox6.Controls.Add(button6);
            groupBox6.Location = new Point(864, 342);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new Size(349, 155);
            groupBox6.TabIndex = 3;
            groupBox6.TabStop = false;
            groupBox6.Text = "groupBox6";
            // 
            // button6
            // 
            button6.FlatAppearance.BorderColor = Color.Teal;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button6.Location = new Point(32, 48);
            button6.Name = "button6";
            button6.Size = new Size(269, 81);
            button6.TabIndex = 2;
            button6.Text = "Warehouses";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // groupBox7
            // 
            groupBox7.Controls.Add(button7);
            groupBox7.Location = new Point(61, 569);
            groupBox7.Name = "groupBox7";
            groupBox7.Size = new Size(349, 155);
            groupBox7.TabIndex = 4;
            groupBox7.TabStop = false;
            groupBox7.Text = "groupBox7";
            // 
            // button7
            // 
            button7.FlatAppearance.BorderColor = Color.Black;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button7.Location = new Point(32, 48);
            button7.Name = "button7";
            button7.Size = new Size(269, 81);
            button7.TabIndex = 2;
            button7.Text = "Users";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // groupBox8
            // 
            groupBox8.Controls.Add(button8);
            groupBox8.Location = new Point(464, 569);
            groupBox8.Name = "groupBox8";
            groupBox8.Size = new Size(349, 155);
            groupBox8.TabIndex = 3;
            groupBox8.TabStop = false;
            groupBox8.Text = "groupBox8";
            // 
            // button8
            // 
            button8.FlatAppearance.BorderColor = Color.Blue;
            button8.FlatStyle = FlatStyle.Flat;
            button8.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button8.Location = new Point(32, 48);
            button8.Name = "button8";
            button8.Size = new Size(269, 81);
            button8.TabIndex = 2;
            button8.Text = "Users Menu";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // groupBox9
            // 
            groupBox9.Controls.Add(button9);
            groupBox9.Location = new Point(864, 569);
            groupBox9.Name = "groupBox9";
            groupBox9.Size = new Size(349, 155);
            groupBox9.TabIndex = 3;
            groupBox9.TabStop = false;
            groupBox9.Text = "groupBox9";
            // 
            // button9
            // 
            button9.FlatAppearance.BorderColor = Color.DodgerBlue;
            button9.FlatStyle = FlatStyle.Flat;
            button9.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button9.Location = new Point(32, 48);
            button9.Name = "button9";
            button9.Size = new Size(269, 81);
            button9.TabIndex = 2;
            button9.Text = "button9";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(label2);
            panel1.Location = new Point(0, 783);
            panel1.Name = "panel1";
            panel1.Size = new Size(1276, 79);
            panel1.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(304, 27);
            label2.Name = "label2";
            label2.Size = new Size(723, 28);
            label2.TabIndex = 0;
            label2.Text = "@2024 WorldSkills Portugal Nacional Exam - Portugal, November, 2024";
            // 
            // btnLogs
            // 
            btnLogs.FlatAppearance.BorderColor = Color.FromArgb(128, 128, 255);
            btnLogs.FlatStyle = FlatStyle.Flat;
            btnLogs.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnLogs.Location = new Point(1099, 21);
            btnLogs.Name = "btnLogs";
            btnLogs.Size = new Size(164, 50);
            btnLogs.TabIndex = 6;
            btnLogs.Text = "Logs";
            btnLogs.UseVisualStyleBackColor = true;
            btnLogs.Click += btnLogs_Click;
            // 
            // btnLogout
            // 
            btnLogout.FlatAppearance.BorderColor = SystemColors.ActiveCaption;
            btnLogout.FlatStyle = FlatStyle.Flat;
            btnLogout.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            btnLogout.Location = new Point(12, 21);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(145, 50);
            btnLogout.TabIndex = 7;
            btnLogout.Text = "Logout";
            btnLogout.UseVisualStyleBackColor = true;
            btnLogout.Click += btnLogout_Click;
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1275, 862);
            Controls.Add(btnLogout);
            Controls.Add(btnLogs);
            Controls.Add(panel1);
            Controls.Add(groupBox9);
            Controls.Add(groupBox8);
            Controls.Add(groupBox7);
            Controls.Add(groupBox6);
            Controls.Add(groupBox5);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Name = "Dashboard";
            Text = "Dashboard";
            groupBox1.ResumeLayout(false);
            groupBox2.ResumeLayout(false);
            groupBox3.ResumeLayout(false);
            groupBox4.ResumeLayout(false);
            groupBox5.ResumeLayout(false);
            groupBox6.ResumeLayout(false);
            groupBox7.ResumeLayout(false);
            groupBox8.ResumeLayout(false);
            groupBox9.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private GroupBox groupBox1;
        private Button btnClientsMenu;
        private GroupBox groupBox2;
        private Button button2;
        private GroupBox groupBox3;
        private Button button3;
        private GroupBox groupBox4;
        private Button button4;
        private GroupBox groupBox5;
        private Button button5;
        private GroupBox groupBox6;
        private Button button6;
        private GroupBox groupBox7;
        private Button button7;
        private GroupBox groupBox8;
        private Button button8;
        private GroupBox groupBox9;
        private Button button9;
        private Panel panel1;
        private Label label2;
        private Button btnLogs;
        private Button btnLogout;
    }
}